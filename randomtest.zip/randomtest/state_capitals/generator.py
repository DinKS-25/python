#import necessary packages
import os 
import random

#state and capitals are stored using dictionary data type
#keys are the state and respective values are the capitals of the state

capitals = {'Alabama': 'Montgomery', 'Alaska': 'Juneau', 'Arizona': 'Phoenix',
   'Arkansas': 'Little Rock', 'California': 'Sacramento', 'Colorado': 'Denver',
   'Connecticut': 'Hartford', 'Delaware': 'Dover', 'Florida': 'Tallahassee',
   'Georgia': 'Atlanta', 'Hawaii': 'Honolulu', 'Idaho': 'Boise', 'Illinois':
   'Springfield', 'Indiana': 'Indianapolis', 'Iowa': 'Des Moines', 'Kansas':
   'Topeka', 'Kentucky': 'Frankfort', 'Louisiana': 'Baton Rouge', 'Maine':
   'Augusta', 'Maryland': 'Annapolis', 'Massachusetts': 'Boston', 'Michigan':
   'Lansing', 'Minnesota': 'Saint Paul', 'Mississippi': 'Jackson', 'Missouri':
   'Jefferson City', 'Montana': 'Helena', 'Nebraska': 'Lincoln', 'Nevada':
   'Carson City', 'New Hampshire': 'Concord', 'New Jersey': 'Trenton', 'New Mexico': 'Santa Fe', 'New York': 'Albany',
   'North Carolina': 'Raleigh', 'North Dakota': 'Bismarck', 'Ohio': 'Columbus', 'Oklahoma': 'Oklahoma City',
   'Oregon': 'Salem', 'Pennsylvania': 'Harrisburg', 'Rhode Island': 'Providence',
   'South Carolina': 'Columbia', 'South Dakota': 'Pierre', 'Tennessee':
   'Nashville', 'Texas': 'Austin', 'Utah': 'Salt Lake City', 'Vermont':
   'Montpelier', 'Virginia': 'Richmond', 'Washington': 'Olympia', 'WestVirginia': 'Charleston', 'Wisconsin': 'Madison', 'Wyoming': 'Cheyenne'}

#loop to generate the number of exam sheets required
for i in range(int(input("enter the number of exam sheets to be made"))):
    #create a question set for each students
    #questionfile contains the question in suffeled order and answerfile contains the correct answer for every question
    questionfile=open("E:\\miniprojects\\randomtest\\capitals\\question\\quizno%s.txt" %(i+1),'w')
    answerfile=open("E:\\miniprojects\\randomtest\\capitals\\answer\\ansno%s.txt" %(i+1),'w')
    questionfile.write(" "*50)
    questionfile.write("quiz on state and there capitals\n")
    questionfile.write("NAME\n")
    questionfile.write("ROLLNO\n")
    state=list(capitals.keys())
    random.shuffle(state)   #shuffles the states random manner
    qno=1
    for c in state:
        correct=capitals[c]
        options=list(capitals.values())
        del options[options.index(correct)]
        options=random.sample(options,3) #select any 3 wrong answers from the collection of the given capitals
        answers=options+[correct]
        random.shuffle(answers)
        questionfile.write("%s.what is the capital of %s.\n" %(qno,c))
        for op in range(4):
            questionfile.write('   %s.%s\n'%('ABCD'[op],answers[op]))
            questionfile.write('\n')
        answerfile.write("%s.%s\n"%(qno,"ABCD"[answers.index(correct)]))
        qno+=1
    questionfile.close()
    answerfile.close()
print("DONE ;)")
